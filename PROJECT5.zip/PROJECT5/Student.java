public class Student{
  String Name;
  int IDNumber;
  int Year;
  String College;
  String Major;

  public static void main(String[] args) {

  }
}
