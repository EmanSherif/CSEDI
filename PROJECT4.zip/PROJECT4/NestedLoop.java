public class NestedLoop{
  public static void Method1() {

  }
  public static void Method2() {

  }
  public static void main(String[] args) {

  }
}
