import java.time.*;
import java.text.*;
import java.io.*;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CSVData{

public static int indexOfNth(String base, String toFind, int n) {
  final int lenToFind = toFind.length();
  int baseIndex = 0;
  String baseSuffix = base;
  for (int toFindCounter=0; toFindCounter<=n; toFindCounter++) {
    int currIndex= baseSuffix.indexOf(toFind);
    if (currIndex == -1) {
      return -1;
    }
    else {
      baseIndex += currIndex;
      baseSuffix = baseSuffix.substring(currIndex+lenToFind,baseSuffix.length());
    }
  }
  return baseIndex + n * lenToFind;
}

public static int parseInt(String s) {
  return Integer.parseInt(s);
}
public static String getLine(String filepath, int row){
  try{
    File file = new File(filepath);
    FileReader fr = new FileReader(file);
    BufferedReader br = new BufferedReader(fr);
    String line = "";
    int valTo = 0;
    while(valTo != row) {
      line = br.readLine();
      valTo++;
    }
    line = br.readLine();
    return line;
  } catch(Exception e) {
    e.printStackTrace();
  }
  return "";
}
public static int getLineCount(String path){
  try{
    File file = new File(path);
    int lines = 0;

    FileInputStream fis = new FileInputStream(file);
    byte[] buffer = new byte[8 * 1024]; // BUFFER_SIZE = 8 * 1024
    int read;

    while ((read = fis.read(buffer)) != -1) {
        for (int i = 0; i < read; i++) {
            if (buffer[i] == '\n') lines++;
        }
    }
    fis.close();
    return lines;
  }catch (Exception e){
    e.printStackTrace();
  }
  return 0;
}

//TODO
public static String[] allLine(String path){
  return null;
}
//TODO
public static double average(String path) {
  return 0.0;
}
//TODO
//create your own Method



public static void main(String[] args) {

}
}
