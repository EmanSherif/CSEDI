import java.util.*;
public class Arrays{
  //TODO
  public static int[] increaseByFactor(int[] arr, int factor) {
    return arr;
  }
  //TODO
  public static int[] differenceInPay(int[] women, int[] men) {
    return women;
  }
  //TODO
  public static int obstaclesToTech(String[] arr, String target) {
    return 0;
  }
  public static void main(String[] args) {
    int [] arr = {0,3,5,7,8,10,9};
    int factor = 3;
    increaseByFactor(arr, factor);
    int[] women = {100000,75000, 60000, 120000 };
    int[] men = {108914, 83914,65,150,148000};
    differenceInPay(women, men);
    String[] obstacles = {"PG", "S", "LR", "PG", "LM", "LM", "PG"};
    String target = "PG";
    obstaclesToTech(obstacles, target);
  }
}
