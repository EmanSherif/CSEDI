public class Loops{
  public static boolean isEven(int val) {
    if((val % 2) == 0) {
      return true;
    } else {
      return false;
    }
  }
  public static boolean isOdd(int val) {
    if((val % 2) != 0) {
      return true;
    }else {
      return false;
    }
  }
  //TODO
  public static int addAll() {
    return 0;
  }
  //TODO
  public static String oddEvenRange(int start, int end) {
    return "";
  }
  public static void main(String[] args) {

  }
}
