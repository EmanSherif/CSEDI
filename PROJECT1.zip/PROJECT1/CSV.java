import java.io.*;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
public class CSV{
  //DO NOT CHANGE
  public static String ReadLine(String filepath, int row){
    try{
      File file = new File(filePath);
      FileReader fr = new FileReader(file);
      BufferedReader br = new BufferedReader(fr);
      String line = "";
      int valTo = 0;
      while(valTo != row) {
        line = br.readLine();
        valTo++;
      }
      line = br.readLine();
      return line;
    } catch(Exception e) {
      e.printStackTrace();
    }
    return "";
  }
  //TODO
  public static String name(String filepath, int row) {
    return "";
  }
  //TODO
  public static String latitude(String filepath, int row) {
    return "";
  }
  //TODO
  public static String longitude(String filepath, int row) {
    return "";
  }

  public static void main(String[] args) {

  }
}
