import java.io.*;
public class Main{
  //TODO
  public static void FixMe() {
    /////////////////////////////////
    // Create a variable that returns the sum of dec + 3
    double dec = 3.5;
    int val = 3 + dec;
    //Print out values
    ////////////////////////////////
    //Create a variable that returns 4 - true
    //You should change as little variables as possible
    int x = 4;
    boolean tf = true;
    int value = x - tf;
    //Print out values
    ////////////////////////////////
    // THIS MUST PRINTOUT HELLO4
    String str = "Hello";
    int valueStr = 4;
    String concat = str + valueStr;
    //Print out values
    ////////////////////////////////
    //You should change as little variables as possible
    double dec2 = 3.5;
    int val2 = 2;
    dec2 = dec2 + val2;
    val2 = dec2 / 2;
    //Print out values
  }
  public static void main(String[] args) {
    FixMe();
    System.out.println("You Did It!");
  }
}
